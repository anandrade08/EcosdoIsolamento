// Velocidade
vel = 2;
velh = 0;
velv = 0;

// Declarando matriz de sprites
sprites[0][0] = spr_paradob; // parado frente
sprites[0][1] = spr_paradoc; // parado cima
sprites[0][2] = spr_paradod; // parado direita
sprites[0][3] = spr_paradoe; // parado esquerda

sprites[1][0] = spr_andandob; // andando frente
sprites[1][1] = spr_andandoc; // andando cima
sprites[1][2] = spr_andandod; // andando direita
sprites[1][3] = spr_andandoe; // andando esquerda

movendo = 0;
lado = 0;


// câmera
cam = camera_create_view(0, 0, 320, 180);

// aplica na view 0
view_enabled = true;
view_visible[0] = true;
view_camera[0] = cam;

// resolução base do jogo (pixel art)
var base_w = 320;
var base_h = 180;

// escala inteira (4x)
var scale = 4;

// define tamanho da janela
window_set_size(base_w * scale, base_h * scale);

// evita blur
gpu_set_texfilter(false);


// GUI no tamanho base
display_set_gui_size(base_w, base_h);

display_set_gui_maximize();

// tamanho padrão (fallback)
global.bg_w = room_width;
global.bg_h = room_height;

