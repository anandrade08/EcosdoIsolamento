
//MOVIMENTOO
var _dir = keyboard_check(vk_right);
var _esq = keyboard_check(vk_left);
var _baixo = keyboard_check(vk_down);
var _cima = keyboard_check(vk_up);

velh = (_dir - _esq) * vel;
velv = (_baixo - _cima) * vel;

x += velh;
y += velv;

// Verifica se está se movendo
if (velh != 0 || velv != 0) {
    movendo = 1;

    if (_dir) lado = 2;
    else if (_esq) lado = 3;
    else if (_baixo) lado = 0;
    else if (_cima) lado = 1;

} else {
    movendo = 0;
}

// Atualiza o sprite
sprite_index = sprites[movendo][lado];

///

//DIALOGOO

#region dialogo
if distance_to_object(obj_narrador) <= 10 {
    if global.tecla and global.dialogo == false {

        var _npc = instance_nearest(x, y, obj_narrador);
        var _dialogo = instance_create_layer(x, y, "Dialogo", obj_dialogo);

        // passa os dados do NPC
        _dialogo.npc_nome   = _npc.npc_nome;
        _dialogo.npc_estado = _npc.npc_estado;

        // guarda quem é o NPC pra devolver o estado depois
        _dialogo.npc_ref = _npc;

        global.dialogo = true;
    }
}

///

//TAMANHO DO BACKGROUND
if (layer_exists("Background")) {
    var lay = layer_get_id("Background");
    var spr = layer_background_get_sprite(lay);

    if (spr != -1) {
        global.bg_w = sprite_get_width(spr);
        global.bg_h = sprite_get_height(spr);
    }
}

//CAMERAAA

// centraliza no player
var cx = x - 160;
var cy = y - 90;

// limita ao tamanho do cenário ATUAL
cx = clamp(cx, 0, global.bg_w - 320);
cy = clamp(cy, 0, global.bg_h - 180);

// aplica posição
camera_set_view_pos(cam, cx, cy);





///