global.dialogo = false;
global.proxima_room = noone;
global.ir_para_room1 = false;
