if instance_exists(obj_dialogo){
	global.dialogo = true;
}

global.tecla = keyboard_check_pressed(ord("Z"));


if (global.ir_para_room1)
{
	global.ir_para_room1 = false;
	room_goto(sala);
}