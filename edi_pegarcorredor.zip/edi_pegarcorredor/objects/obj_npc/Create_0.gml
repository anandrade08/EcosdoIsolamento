npc_nome   = "NPC_TESTE";
npc_estado = "inicio";