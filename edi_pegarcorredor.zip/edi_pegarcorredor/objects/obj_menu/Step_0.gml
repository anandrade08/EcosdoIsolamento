// Navegação
if (keyboard_check_pressed(vk_down)) {
    index++;
    if (index > op_max - 1) index = 0;
}

if (keyboard_check_pressed(vk_up)) {
    index--;
    if (index < 0) index = op_max - 1;
}

// Seleção
if (keyboard_check_pressed(ord("Z"))) {
    switch (index) {
        case 0:
            room_goto_next();
        break;

        case 3:
            game_end();
        break;
    }
}
