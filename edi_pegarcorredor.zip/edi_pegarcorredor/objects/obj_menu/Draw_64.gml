// =============================
// CONFIG
// =============================
var cx = display_get_gui_width() * 0.5;

// escala da logo (AJUSTE AQUI)
var scale_logo = 0.6;

// posição vertical da logo (AJUSTE AQUI)
var logo_y = 200;  // AQUI VOCÊ SOBE OU DESCE A LOGO

// =============================
// DESENHAR LOGO (CENTRALIZADA)
// =============================
var logo = spr_logo;

draw_sprite_ext(
    logo,
    0,
    cx,
    logo_y,
    scale_logo,
    scale_logo,
    0,
    c_white,
    1
	
	
);

// ///////////////////////////////
// TÍTULO – fica logo abaixo
// ///////////////////////////////

draw_set_font(ft_menu);
draw_set_halign(fa_center);

// GARANTE QUE O TÍTULO TENHA A COR CORRETA
draw_set_color(c_white);

var titulo_y = logo_y + sprite_get_height(logo) * scale_logo + -100; 
// ↑ esse "10" é a distância da logo pro título (AJUSTE AQUI)

draw_text(cx, titulo_y, "ECOS DO ISOLAMENTO");

// ///////////////////////////////
// MENU – fica logo abaixo do título
// ///////////////////////////////

draw_set_font(ft_menu);

var menu_start_y = titulo_y + 60;  
// ↑ distância título → menu (AJUSTE AQUI)

var dist = 55;

for (var i = 0; i < op_max; i++) {
    draw_set_color(i == index ? c_yellow : c_white);
    draw_text(cx, menu_start_y + i * dist, opcoes[i]);
}
