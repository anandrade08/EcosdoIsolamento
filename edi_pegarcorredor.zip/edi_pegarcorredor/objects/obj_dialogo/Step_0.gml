if inicializar == false{
	scr_textos();
	inicializar = true;
	alarm[0] = 1;
}

if caractere < string_length(texto_grid[# Infos.Texto, pagina]){
	if global.tecla{
		caractere = string_length(texto_grid[# Infos.Texto, pagina]);
	}
}

	else{
		if pagina < ds_grid_height(texto_grid) - 1{
			if global.tecla{
				alarm[0] = 1;
				caractere = 0;
				pagina++;
			}
		}
		
		else{	
			if op_num != 0{
				op_draw = true;
			}
		
    if (op_draw && global.tecla) {

    // muda o estado de acordo com a opção escolhida
    npc_estado = op_resposta[op_selecionada];

    // limpa o diálogo atual
    texto_grid = ds_grid_create(4, 0);
    pagina = 0;
    caractere = 0;

    op_draw = false;
    op_num = 0;
    op_selecionada = 0;

    inicializar = false;

    global.tecla = false;
	
}

// FECHAR DIÁLOGO

if (dialogo_finaliza && pagina >= ds_grid_height(texto_grid) - 1) {
    if (global.tecla) {

        if (npc_ref != noone) {
            npc_ref.npc_estado = npc_estado;
        }

        instance_destroy(); 
    }
}

//////////////////
	
		}
		
	}
	