function scr_textos() {

    switch (npc_nome) {

        case "NPC_TESTE":

            switch (npc_estado) {

                // PRIMEIRA VEZ
                case "inicio":
                    ds_grid_add_text("oi..", spr_npc, 1, "NPC");
                    ds_grid_add_text("de boa?", spr_npc, 1, "NPC");

                    add_op("Nao responder",         "resp_ignorar");
                    add_op("Mandar se fuder",       "resp_bravo");
                    add_op("Responder que ta bem",  "resp_amigo");
                break;

                // ESCOLHAS
                case "resp_ignorar":
                    ds_grid_add_text("...", spr_retratoaub, 0, "Player");
                    ds_grid_add_text("vish eh muda", spr_npc, 1, "NPC");

                    npc_estado = "frio";
					dialogo_finaliza = true;
                break;

                case "resp_bravo":
                    ds_grid_add_text("vai se fuder", spr_retratoaub, 0, "Player");
                    ds_grid_add_text("vai voce prc", spr_npc, 1, "NPC");

                    npc_estado = "bravo";
					dialogo_finaliza = true;
                break;

                case "resp_amigo":
                    ds_grid_add_text("Eai to bem sim e vc", spr_retratoaub, 0, "Player");
                    ds_grid_add_text("Que bom!! Eu tb", spr_npc, 1, "NPC");

                    npc_estado = "amigo";
					dialogo_finaliza = true;
                break;

                // CONVERSAS FUTURAS
                case "amigo":
                    ds_grid_add_text("Eai!! Bom te ver de novo ", spr_npc, 1, "NPC");
                break;

                case "bravo":
                    ds_grid_add_text("Nao quero falar com vc ", spr_npc, 1, "NPC");
                break;

                case "frio":
                    ds_grid_add_text("...", spr_npc, 1, "NPC");
                break;
				
				
		
            }

        break;
    }
}
	   
	   
	   ////ESCOLA - CENA 1.
	   
	//case "aaaa":
		//ds_grid_add_text("Ei… você sabe onde fica a sala 61?", spr_retratoaub, 0, "Aubreyslacomoescreve");
        //ds_grid_add_text("Sai de perto, novato!", spr_npc, 1, "NPC");
		//ds_grid_add_text("Ok, procuro sozinho então.", spr_retratoaub, 0, "Aubreyslacomoescreve");
		//ds_grid_add_text("Droga… vou chegar atrasado.", spr_retratoaub, 0, "Aubreyslacomoescreve");
		
		//global.proxima_room = Room1;
	
	// break;
		
	
	//}
//}


function ds_grid_add_row(){
    ///@arg ds_grid
    var _grid = argument[0];
    ds_grid_resize(_grid, ds_grid_width(_grid), ds_grid_height(_grid)+1);
    return (ds_grid_height(_grid)-1);
}

function ds_grid_add_text(){
	///@arg texto
	///@arg retrato 
	///@arg lado
	///@arg nome
	var _grid = texto_grid;
	var _y = ds_grid_add_row(_grid);
	
	_grid[# 0, _y] = argument[0];
	_grid[# 1, _y] = argument[1];
	_grid[# 2, _y] = argument[2];
	_grid[# 3, _y] = argument[3];
}	

function add_op(_texto, _resposta){
	op[op_num] = _texto;
	op_resposta[op_num] = _resposta;
	
	op_num++;
}