function scr_seq_inicio()
{
	global.ir_para_room1 = true;
}